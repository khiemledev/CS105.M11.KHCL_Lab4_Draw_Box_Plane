# Lab4 Draw a box and plane with threejs

## Install dependencies

To install the dependencies, run the following command:
```bash
npm install
```

## Run the code

To run the code, run the following command:
```bash
npm run dev
```

The command below start a local server at port 3000, visit it at http://localhost:3000/ to see the result.